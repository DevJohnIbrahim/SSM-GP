package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    private EditText editTextFullName;
    private EditText editTextUsername;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private RadioGroup radioGroupGender;
    private Button Register;
    private RadioButton radioSexButton;
    private DocumentReference Database;
    private FirebaseAuth Auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Register = findViewById(R.id.register);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextFullName = findViewById(R.id.FullName);
                editTextUsername = findViewById(R.id.Username);
                editTextEmail = findViewById(R.id.Email);
                editTextPassword = findViewById(R.id.password);
                radioGroupGender = findViewById(R.id.Gender);
                final String FullName = editTextFullName.getText().toString().trim();
                final String Username = editTextUsername.getText().toString().trim();
                final String Email = editTextEmail.getText().toString().trim();
                String Password = editTextPassword.getText().toString().trim();
                int selectedId = radioGroupGender.getCheckedRadioButtonId();
                radioSexButton = (RadioButton) findViewById(selectedId);
                final String Gender = radioSexButton.getText().toString().trim();
                Auth = FirebaseAuth.getInstance();
                Auth.createUserWithEmailAndPassword(Email , Password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Map<String , Object> DataToAdd = new HashMap<String, Object>();
                        DataToAdd.put("Name" , FullName);
                        DataToAdd.put("Username" , Username);
                        DataToAdd.put("Email" , Email);
                        DataToAdd.put("Gender" , Gender);
                        Database = FirebaseFirestore.getInstance().document("Users/"+Auth.getUid());
                        Database.set(DataToAdd).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast toast = Toast.makeText(getApplicationContext() , "Registeration Successful" , Toast.LENGTH_LONG);
                                toast.show();
                                Intent intent = new Intent(getApplicationContext() , MainScreen.class);
                                startActivity(intent);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast toast = Toast.makeText(getApplicationContext() , "Something Wrong Happened" , Toast.LENGTH_LONG);
                                toast.show();
                            }
                        });


                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast toast = Toast.makeText(getApplicationContext() , "Something Wrong Happened" , Toast.LENGTH_LONG);
                        toast.show();

                    }
                });
            }
        });
    }
}
