package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Iterator;

public class Chat extends Fragment{
    private ArrayList<String> StringArray;
    private ArrayList<String> AnotherArray;
    private FirebaseAuth Auth;
    private CollectionReference Database;
    private DocumentReference Database2;
    private CollectionReference Database3;
    private ArrayList<String> Friends;
    private ArrayList<String> FriendsID;
    private ListView listView;
    private ArrayAdapter adapter;
    private View view;
    private boolean bool;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_chats , null );
        listView = view.findViewById(R.id.chat_list);
        Auth = FirebaseAuth.getInstance();
        Friends = new ArrayList<String>();
        FriendsID = new ArrayList<String>();
        StringArray =new ArrayList<String>();
        AnotherArray =new ArrayList<String>();
        chat();
        (new Handler()).postDelayed(this::check, 2000);

        return view;
    }


    public boolean chat(){
        bool= false;
        Database = FirebaseFirestore.getInstance().collection("Users").document(Auth.getUid()).collection("Friends");
        Database.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if (!queryDocumentSnapshots.isEmpty()){

                    for (final QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        final String ID= document.getString("ID");
                        Database2 = FirebaseFirestore.getInstance().collection("Users").document(ID);
                        Database2.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                Friends.add(documentSnapshot.getString("Name"));
                                FriendsID.add(ID);
                                Log.d("CheckPoint" , "Finished the Friends");
                                bool=true;
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast toast = Toast.makeText(getActivity().getApplicationContext() , "Fail" , Toast.LENGTH_LONG);
                                toast.show();
                            }
                        });

                    }


                }
            }

        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast toast = Toast.makeText(getActivity().getApplicationContext() , "Fail" , Toast.LENGTH_LONG);
                toast.show();
            }
        });

       return bool;
    }
    public void check(){
        if(Friends.isEmpty()) {
            StringArray.add("No chat available");
            update(view);

        }
        else{
            getChat(view);
        }
    }

    public void update(View v){
        System.err.println(StringArray);
        if (getActivity()!=null) {
            adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, StringArray);
        }
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object selectedItem =  parent.getItemAtPosition(position);
                if(!selectedItem.toString().equals("No chat available")) {
                    Intent intent = new Intent(getActivity().getApplicationContext(), ChatScreen.class);
                    intent.putExtra("FriendName", StringArray.get(position));
                    intent.putExtra("ChatID", AnotherArray.get(position));
                    startActivity(intent);
                }
            }
        });
    }

    public void getChat(final View view){

        Database3 = FirebaseFirestore.getInstance().collection("Chat");
        Database3.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                ArrayList<String> Friendsit = new ArrayList<String>();
                ArrayList<String> FriendsIDit = new ArrayList<String>();
                Friendsit=Friends;
                FriendsIDit=FriendsID;
                if (!queryDocumentSnapshots.isEmpty()) {

                    for (final QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        for (Iterator<String> iterator = FriendsIDit.iterator(); iterator.hasNext(); ) {
                            String friendid = iterator.next();
                            String sender_receiver=document.getString("sender_receiver");
                            if ((sender_receiver.equals(Auth.getUid() + "_" + friendid))||(sender_receiver.equals(friendid+ "_" + Auth.getUid())))
                            {
                                StringArray.add(Friendsit.get(FriendsIDit.indexOf(friendid)));
                                AnotherArray.add(document.getId());
                                Friendsit.remove(FriendsIDit.indexOf(friendid));
                                iterator.remove();
                            }
                        }
                    }

                }
                else{
                    StringArray.add("No chat available");
                    update(view);
                }
                if(StringArray.isEmpty()) {
                    StringArray.add("No chat available");
                    update(view);

                }
                else{
                    update(view);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                StringArray.add("No chat available");
                Toast toast = Toast.makeText(getActivity().getApplicationContext() , "Fail" , Toast.LENGTH_LONG);
                toast.show();
                update(view);

            }
        });
    }

}
