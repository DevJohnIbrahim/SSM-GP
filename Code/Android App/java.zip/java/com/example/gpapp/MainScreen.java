package com.example.gpapp;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainScreen extends AppCompatActivity {
    private TextView WelcomeMessage;
    private FirebaseAuth Auth;
    private DocumentReference Database;
    private Button OurChat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
        WelcomeMessage = findViewById(R.id.WelcomeMessage);
        Auth = FirebaseAuth.getInstance();
        Database = FirebaseFirestore.getInstance().document("Users/"+Auth.getUid());
        Database.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String Name = documentSnapshot.getString("Name");
                WelcomeMessage.setText("Welcome " +Name+",");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast toast = Toast.makeText(getApplicationContext() , "Something Went Wrong" , Toast.LENGTH_LONG);
                toast.show();
            }
        });
        OurChat = findViewById(R.id.OurChat);
        OurChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext() , ChatMain.class);
                startActivity(intent);
            }
        });

    }
}
