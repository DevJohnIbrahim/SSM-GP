package com.example.gpapp;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    private Button Login;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private FirebaseAuth Auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Login = findViewById(R.id.Login);
        editTextEmail = findViewById(R.id.Email);
        editTextPassword = findViewById(R.id.password);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Email = editTextEmail.getText().toString().trim();
                String Password = editTextPassword.getText().toString().trim();
                Auth = FirebaseAuth.getInstance();
                Auth.signInWithEmailAndPassword(Email , Password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast toast = Toast.makeText(getApplicationContext() , "Login Success" , Toast.LENGTH_LONG);
                        toast.show();
                        Intent intent = new Intent(getApplicationContext() , MainScreen.class);
                        startActivity(intent);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast toast = Toast.makeText(getApplicationContext() , "Login Failed" , Toast.LENGTH_LONG);
                        toast.show();
                    }
                });
            }
        });
    }
}
