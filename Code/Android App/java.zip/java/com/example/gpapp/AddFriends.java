package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddFriends extends Fragment implements View.OnClickListener {
    @Nullable
    private EditText SearchText;
    private Button SearchButton;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_friends, container, false);
        SearchText = view.findViewById(R.id.Search3);
        SearchButton = view.findViewById(R.id.FindFriend3);
        SearchButton.setOnClickListener(this);
        return view;

    }
    private void AddNewFriend(){
        Log.d("Messagae" , "You Clicked on the Button");
        String UserId = "";
        UserId = SearchText.getText().toString().trim();
        if (UserId.equals("")){
            Toast toast = Toast.makeText(getActivity().getApplicationContext() , "Please enter some text First" , Toast.LENGTH_LONG);
            toast.show();
        }
        else{
            Intent intent = new Intent(getActivity().getApplicationContext() , SearchScreen.class);
            intent.putExtra("UserID" , UserId);
            startActivity(intent);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.FindFriend3:
                AddNewFriend();
                break;
        }

    }
}
