package com.example.gpapp;

import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.widget.TextView;

public class ChatMain extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_main);
        Bundle Message = getIntent().getExtras();
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(this);
        if(Message !=null){
            String fragment=Message.getString("Fragment");
            if(fragment.equals("Friends")){
                loadFragment(new Friends());
            }
            else if(fragment.equals("AddFriends")){
                loadFragment(new AddFriends());
            }
        }
        else{
            loadFragment(new Chat());
        }


    }

    private boolean loadFragment(Fragment fragment){
        if (fragment != null){
            getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_Container , fragment).commit();
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;
        switch (menuItem.getItemId()){
            case R.id.Chats:
                fragment = new Chat();
                break;
            case R.id.Friends:
                fragment = new Friends();
                break;
            case R.id.AddFriends:
                fragment = new AddFriends();
                break;
        }
        return loadFragment(fragment);
    }
}
