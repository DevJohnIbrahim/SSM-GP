package com.example.gpapp;


import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.auth.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static android.R.layout.simple_list_item_1;

public class SearchScreen extends AppCompatActivity {
    private DocumentReference Database;
    private CollectionReference Database2;
    private DocumentReference Database3;
    private  CollectionReference Database4;
    private ListView listViewFriends;
    private FirebaseAuth Auth;
    private Button BackButton;
    private boolean isfriend;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> Names;
    private ArrayList<String> IDs;
    private String MyName;
    private String ID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Auth = FirebaseAuth.getInstance();
        Names = new ArrayList<String>();
        IDs = new ArrayList<String>();
        setContentView(R.layout.activity_search_screen);
        Bundle Message = getIntent().getExtras();
        ID = Message.getString("UserID");
        BackButton = findViewById(R.id.button);
        listViewFriends = findViewById(R.id.FriendListSearch);
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext() , ChatMain.class);
                intent.putExtra("Fragment","AddFriends");
                startActivity(intent);
            }
        });
        Auth = FirebaseAuth.getInstance();
        Database = FirebaseFirestore.getInstance().document("Users/"+ID);
        ArrayList<String> Friendsid= getFriends();

    }

    private void AddFriend(int position){

        String SelectedFriendID = IDs.get(position);
        String SelectedFriendName = Names.get(position);
        Database = FirebaseFirestore.getInstance().collection("Users").document(Auth.getUid());
        Database.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                MyName = documentSnapshot.getString("Name");
                Database = FirebaseFirestore.getInstance().collection("Users").document(Auth.getUid()).collection("Friends").document(SelectedFriendID);
                Map<String , Object> DataToAdd = new HashMap<String, Object>();
                Map<String , Object> DataToAdd2 = new HashMap<String , Object>();
                Date date = new Date();
                DataToAdd.put("Friends Since" , date);
                DataToAdd.put("ID" , SelectedFriendID);
                DataToAdd.put("Name" , SelectedFriendName);
                Database.set(DataToAdd).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Database = FirebaseFirestore.getInstance().collection("Users").document(SelectedFriendID).collection("Friends").document(Auth.getUid());
                        DataToAdd2.put("Friends Since" , date);
                        DataToAdd2.put("ID" , Auth.getUid());
                        DataToAdd2.put("Name" , MyName);
                        Database.set(DataToAdd2).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast toast = Toast.makeText(getApplicationContext() , "Added Successfully" , Toast.LENGTH_LONG);
                                toast.show();
                                Intent intent = new Intent(getApplicationContext() , ChatMain.class);
                                intent.putExtra("Fragment","Friends");
                                startActivity(intent);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Database = FirebaseFirestore.getInstance().collection("Users").document(SelectedFriendID).collection("Friends").document(Auth.getUid());
                                Database.delete();
                            }
                        });
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast toast = Toast.makeText(getApplicationContext() , "Sorry Something Went wrong" , Toast.LENGTH_LONG);
                        toast.show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast toast = Toast.makeText(getApplicationContext() , "Sorry Something Went Wrong" , Toast.LENGTH_LONG);
                toast.show();
            }
        });

        Toast toast = Toast.makeText(getApplicationContext() , ""+SelectedFriendID , Toast.LENGTH_LONG);
        toast.show();
    }

    public ArrayList<String> getFriends() {
       ArrayList<String> FriendsID=new ArrayList<String>();
        Database4 = FirebaseFirestore.getInstance().collection("Users").document(Auth.getUid()).collection("Friends");
        Database4.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if (!queryDocumentSnapshots.isEmpty()){

                    for (final QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        final String ID= document.getString("ID");
                        FriendsID.add(ID);
                    }


                }
                Database2 = FirebaseFirestore.getInstance().collection("Users");
                Database2.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot document: queryDocumentSnapshots) {
                            isfriend=false;
                            String RetrievedName = document.getString("Name").toLowerCase();
                            String RetrievedID = document.getId();
                            String SearchedString = ID.toLowerCase();
                            String RetrievedUsername = document.getString("Username").toLowerCase();
                            Iterator i = FriendsID.iterator();
                            System.out.println("The ArrayList elements are:"+RetrievedID);
                            while (i.hasNext()) {
                                if(RetrievedID.equals(i.next().toString())){
                                    isfriend=true;
                                }
                            }

                            if ((RetrievedName.contains(SearchedString) || RetrievedUsername.contains(SearchedString))&&(isfriend==false)&&(!RetrievedID.equals(Auth.getUid()))) {
                                Names.add(document.getString("Name"));
                                IDs.add(document.getId());

                            }

                        }

                        adapter = new ArrayAdapter<String>(getApplicationContext() , simple_list_item_1, Names);
                        listViewFriends.setAdapter(adapter);
                    }
                });
                listViewFriends.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        AddFriend(position);

                    }
                });

            }

        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast toast = Toast.makeText(getApplicationContext() , "Fail" , Toast.LENGTH_LONG);
                toast.show();
            }
        });
        return FriendsID;
    }
}
