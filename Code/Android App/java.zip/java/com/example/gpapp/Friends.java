package com.example.gpapp;
import android.R.layout;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.api.core.ApiFuture;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static android.R.layout.*;

public class Friends extends Fragment implements View.OnClickListener {
    private Button SearchButton;
    private FirebaseAuth Auth;
    private CollectionReference Database;
    private DocumentReference Database2;
    private ArrayList<String> Friends;
    private ArrayList<String> FriendsID;
    private ArrayAdapter<String> adapter;
    private ListView listViewFriends;
    private ArrayList<String> AnotherArray;
    private TextView NoFriendMessage;
    private QuerySnapshot ReturnedFriends;
    private String DocumentID;
    public Friends() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_friends, container, false);
        listViewFriends = view.findViewById(R.id.FriendList);
        AnotherArray =new ArrayList<String>();
        ViewFriends(view);
        listViewFriends.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                GetChats(FriendsID.get(position) , position);

            }
        });
        return view;
    }

    public void ViewFriends(View view){
        Friends = new ArrayList<String>();
        FriendsID = new ArrayList<String>();
        Auth = FirebaseAuth.getInstance();
        Database = FirebaseFirestore.getInstance().collection("Users").document(Auth.getUid()).collection("Friends");
        Database.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for (QueryDocumentSnapshot Query:
                     queryDocumentSnapshots) {
                    Friends.add(Query.getString("Name"));
                    FriendsID.add(Query.getId());
                }
                    adapter = new ArrayAdapter<String>(getActivity() , simple_list_item_1, Friends);
                    listViewFriends.setAdapter(adapter);

            }
        });


    }
//    public void CreatChat(String FriendID , int postion){
//        Database = FirebaseFirestore.getInstance().collection("chat");
//        Map<String , String> Datatoset = new HashMap<String , String>();
//        Datatoset.put("sender_receiver" , Auth.getUid()+"_"+FriendID);
//        Database.add(Datatoset).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//            @Override
//            public void onSuccess(DocumentReference documentReference) {
//                GetChats(FriendID , postion);
//            }
//        });
//    }
    public void GotoChat(int position){
        Intent intent = new Intent(getActivity().getApplicationContext() , ChatScreen.class);
        intent.putExtra("FriendName" , Friends.get(position));
        intent.putExtra("ChatID" , DocumentID);
        startActivity(intent);
    }
    public void GetChats(String FriendID , int postion){
        Database = FirebaseFirestore.getInstance().collection("Chat");
        Database.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for (QueryDocumentSnapshot document:queryDocumentSnapshots) {
                    if (document.getString("sender_receiver").equals( Auth.getUid()+"_"+FriendID) || document.getString("sender_receiver").equals(FriendID+"_"+Auth.getUid())){
                        DocumentID = document.getId();
                    }
                }
                if (DocumentID == null){
                    CreateChat(FriendID , postion);
                }
                else{
                    GotoChat(postion);
                }
            }
        });

    }
    public void CreateChat(String FriendID , int position){
        Database = FirebaseFirestore.getInstance().collection("Chat");
        Map<String , String> DatatoPut = new HashMap<String ,String>();
        DatatoPut.put("sender_receiver" , Auth.getUid()+"_"+FriendID);
        Database.add(DatatoPut).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                GetChats(FriendID , position);
            }
        });
    }

    @Override
    public void onClick(View v) {

    }
}
